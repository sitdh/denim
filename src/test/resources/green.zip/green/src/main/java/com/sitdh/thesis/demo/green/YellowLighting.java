package com.sitdh.thesis.demo.green;

public class YellowLighting implements Lighting {
	
	private Timer timer;
	
	public YellowLighting() { 
		timer = new Timer();
	}

	public void lighting() {
		System.out.println("Yellow");
		timer.wait(10);
	}

}
