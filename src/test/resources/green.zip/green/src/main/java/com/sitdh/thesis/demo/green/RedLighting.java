package com.sitdh.thesis.demo.green;

public class RedLighting implements Lighting {
	
	private Timer timer;
	
	public RedLighting() {
		timer = new Timer();
	}

	public void lighting() {
		System.out.println("Red");
		timer.wait(30);
	}

}
