package com.sitdh.thesis.demo.green;

public class NotificationCenter {

	public NotificationCenter() {
		
	}
	
	public String notification() {
		return "*";
	}
}
