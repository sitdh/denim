package com.sitdh.thesis.demo.green;

public class Timer {
	
	private boolean isNotified;
	
	private NotificationCenter notify;
	
	public Timer() {
		notify = new NotificationCenter();
	}
	
	public boolean wait(int second) {
		
		boolean passed = false;
		
		System.out.print("Wait: ");
		
		for(int i = 0; i < second; i++) {
			System.out.print(" " + i);
			
			if (i == second - 2) {
				System.out.print(notify.notification() + " ");
			}
		}
		
		System.out.println();
		
		passed = isNotified;
		
		return passed;
	}

}
