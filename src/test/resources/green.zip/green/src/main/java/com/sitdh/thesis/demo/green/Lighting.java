package com.sitdh.thesis.demo.green;

public interface Lighting {

	public void lighting();
	
}
