package com.sitdh.thesis.demo.green;

public class GreenLighting implements Lighting {

	private Timer timer;
	
	public GreenLighting() {
		timer = new Timer();
	}
	
	public void lighting() {
		System.out.println("Green");
		timer.wait(10);
	}

}
