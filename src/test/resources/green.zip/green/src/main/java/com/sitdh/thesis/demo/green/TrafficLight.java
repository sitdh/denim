package com.sitdh.thesis.demo.green;

public class TrafficLight {
	
	private YellowLighting yellow;
	
	private RedLighting red;
	
	private GreenLighting green;

	public TrafficLight() {
		yellow = new YellowLighting();
		
		red = new RedLighting();
		
		green = new GreenLighting();
	}
	
	public void print(String lighting) {
		
		if ("red".equals(lighting)) {
			red.lighting();
		} else if ("green".equals(lighting)) {
			green.lighting();
		} else {
			System.out.println("ERROR: " + lighting);
		}
	}

	public static void main(String[] args) {
		
		TrafficLight traffic = new TrafficLight();
		
		for (String arg : args) {
            traffic.print(arg);
        }
	}
}
